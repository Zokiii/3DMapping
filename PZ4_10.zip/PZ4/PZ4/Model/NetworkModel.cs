﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PZ3.Model
{
    [Serializable]
    public class NetworkModel
    {
        private List<SubstationEntity> substations;
        private List<SwitchEntity> switches;
        private List<LineEntity> lines;
        private List<NodeEntity> nodes;

        public NetworkModel() { }

        public List<SubstationEntity> Substations
        {
            get { return substations; }
            set { substations = value; }
        }

        public List<SwitchEntity> Switches
        {
            get { return switches; }
            set { switches = value; }
        }

        public List<LineEntity> Lines
        {
            get { return lines; }
            set { lines = value; }
        }

        public List<NodeEntity> Nodes
        {
            get { return nodes; }
            set { nodes = value; }
        }
    }
}
