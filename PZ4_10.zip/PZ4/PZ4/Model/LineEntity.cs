﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace PZ3.Model
{
    public enum ConductorMaterial { Steel, Acsr, Copper, Other }
    public enum LineType { Cable, Overhead }

    [Serializable]
    public class LineEntity
    {
        private string id;
        private string name;
        private bool isUnderground;
        private double r;
        private ConductorMaterial conductorMaterial;
        private LineType lineType;
        private int thermalConstantHeat;
        private string firstEnd;
        private string secondEnd;
        private List<Point> vertices;
        private int vertexCount;

        public LineEntity() { }

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        [XmlIgnore]
        public int VertexCount
        {
            get { return vertexCount; }
            set { vertexCount = value; }
        }

        public bool IsUnderground
        {
            get { return isUnderground; }
            set { isUnderground = value; }
        }

        public double R
        {
            get { return r; }
            set { r = value; }
        }

        public ConductorMaterial ConductorMaterial
        {
            get { return conductorMaterial; }
            set { conductorMaterial = value; }
        }

        public LineType LineType
        {
            get { return lineType; }
            set { lineType = value; }
        }

        public int ThermalConstantHeat
        {
            get { return thermalConstantHeat; }
            set { thermalConstantHeat = value; }
        }

        public string FirstEnd
        {
            get { return firstEnd; }
            set { firstEnd = value; }
        }

        public string SecondEnd
        {
            get { return secondEnd; }
            set { secondEnd = value; }
        }

        public List<Point> Vertices
        {
            get { return vertices; }
            set { vertices = value; }
        }
    }
}
