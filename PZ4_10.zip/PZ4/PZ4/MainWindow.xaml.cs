﻿using PZ3.Model;
using PZ3.XmlModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PZ4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Dictionary<string, KeyValuePair<int, int>> matrix = new Dictionary<string, KeyValuePair<int, int>>();
        private XmlParser xmlParser = new XmlParser();
        public Point3DCollection Positions { get; private set; }
        public Int32Collection Indicies { get; private set; }
        private ArrayList models = new ArrayList();
        private List<object> allObjects = new List<object>();
        private ToolTip toolTip = new ToolTip();
        private Dictionary<System.Windows.Point, int> objectsCache = new Dictionary<System.Windows.Point, int>(100);

        private System.Windows.Point start = new System.Windows.Point();
        private System.Windows.Point startRotation = new System.Windows.Point();
        private System.Windows.Point diffOffset = new System.Windows.Point();
        private int zoomMax = 1000;
        private int zoomCurent = 1;
        private double cubeSize = 0.01;
        private double lineSize = 0.005;
        private double lineRadio = 0.002;
        private double lineWidth = 0.002;
        private double mapSize = 1;
        private double minX = 45.2325;
        private double maxX = 45.277031;
        private double minY = 19.793909;
        private double maxY = 19.894459;

        public MainWindow()
        {
            InitializeComponent();
            //viewPort3d.PanGesture = new MouseGesture(MouseAction.LeftClick);
            //viewPort3d.RotateGesture = new MouseGesture(MouseAction.RightClick);

            DrawSubstations();
            DrawSwitches();
            DrawNodes();
            DrawLines();
        }

        private void DrawLines()
        {
            foreach (var line in xmlParser.NetworkModel.Lines)
            {
                double latitude;
                double longitude;
                List<System.Windows.Point> points = new List<System.Windows.Point>();

                foreach (var dot in line.Vertices)
                {
                    ToLatLon(dot.X, dot.Y, 34, out latitude, out longitude);
                    if (latitude < 45.2325 || latitude > 45.277031 || longitude < 19.793909 || longitude > 19.894459)
                        continue;

                    System.Windows.Point point = ApproximateFunction(latitude, longitude);
                    points.Add(point);
                }

                DrawLine(points, line.ConductorMaterial);
            }
        }

        private void DrawLine(List<System.Windows.Point> points, ConductorMaterial conductorMaterial)
        {
            DiffuseMaterial material = new DiffuseMaterial();

            //Indicies = new Int32Collection()
            //{
            //    0,1,2,  1,3,2,  0,4,2,  4,6,2,  5,1,7,  1,3,7,  6,7,2,  7,3,2,  4,5,0,  5,1,0,  4,5,6,  5,7,6
            //};

            Indicies = new Int32Collection()
            {
                2,3,1,  2,1,0,  7,1,3,  7,5,1,  6,5,7,  6,4,5,  6,2,4,  2,0,4,  2,7,3,  2,6,7,  0,1,5,  0,5,4
            };

            switch (conductorMaterial)
            {
                case ConductorMaterial.Steel:
                    material = new DiffuseMaterial(Brushes.Gold);
                    break;
                case ConductorMaterial.Copper:
                    material = new DiffuseMaterial(Brushes.Orchid);
                    break;
                case ConductorMaterial.Acsr:
                    material = new DiffuseMaterial(Brushes.Red);
                    break;
                default:
                    material = new DiffuseMaterial(Brushes.DarkOrange);
                    break;
            }

            for (int i = 0; i < points.Count - 1; i++)
            {
                Positions = new Point3DCollection()
                {
                    new Point3D(points[i].X, points[i].Y, lineRadio),
                    new Point3D(points[i].X + lineWidth, points[i].Y, lineRadio),
                    new Point3D(points[i].X, points[i].Y, lineSize + lineRadio),
                    new Point3D(points[i].X + lineWidth, points[i].Y, lineSize + lineRadio),
                    new Point3D(points[i + 1].X, points[i + 1].Y, lineRadio),
                    new Point3D(points[i + 1].X + lineWidth, points[i + 1].Y, lineRadio),
                    new Point3D(points[i + 1].X , points[i + 1].Y, lineSize + lineRadio),
                    new Point3D(points[i + 1].X + lineWidth, points[i + 1].Y, lineSize + lineRadio),
                };

                GeometryModel3D firstObj = new GeometryModel3D();
                firstObj.Material = material;
                firstObj.Geometry = new MeshGeometry3D() { Positions = Positions, TriangleIndices = Indicies };

                geomap.Children.Add(firstObj);
            }

        }

        private void DrawNodes()
        {
            foreach (var node in xmlParser.NetworkModel.Nodes)
            {
                double latitude;
                double longitude;

                ToLatLon(node.X, node.Y, 34, out latitude, out longitude);
                if (latitude < 45.2325 || latitude > 45.277031 || longitude < 19.793909 || longitude > 19.894459)
                    continue;
                if(node.Id == "37093")
                {
                    int x = 4;
                }
                System.Windows.Point point = ApproximateFunction(latitude, longitude);
                double offset = GetOffset(point);
                DrawNode(point, node, offset);
                SaveObjectToCache(point);
            }
        }

        private double GetOffset(System.Windows.Point point)
        {
            System.Windows.Point temp = new System.Windows.Point(Math.Round(point.X, 2), Math.Round(point.Y, 2));
            double offset = 0.002;
            int counter;
            if (objectsCache.TryGetValue(temp, out counter))
            {
                offset += counter / 100.0;
            }


            for (int i = 1; i < 4; i++)
            {
                temp.X -= cubeSize*i;
                if (objectsCache.TryGetValue(temp, out counter))
                {
                    offset += counter / 100.0 + 0.01;
                }
                temp.X = point.X;

                temp.X += cubeSize * i;
                if (objectsCache.TryGetValue(temp, out counter))
                {
                    offset += counter / 100.0 + 0.01;
                }
                temp.X = point.X;

                temp.Y -= cubeSize * i;
                if (objectsCache.TryGetValue(temp, out counter))
                {
                    offset += counter / 100.0 + 0.01;
                }
                temp.Y = point.Y;

                temp.Y += cubeSize * i;
                if (objectsCache.TryGetValue(temp, out counter))
                {
                    offset += counter / 100.0 + 0.01;
                }
                temp.Y = point.Y;

                temp.Y -= cubeSize * i;
                temp.X -= cubeSize * i;
                if (objectsCache.TryGetValue(temp, out counter))
                {
                    offset += counter / 100.0 + 0.01;
                }
                temp.Y = point.Y;
                temp.X = point.X;

                temp.Y += cubeSize * i;
                temp.X += cubeSize * i;
                if (objectsCache.TryGetValue(temp, out counter))
                {
                    offset += counter / 100.0 + 0.01;
                }
                temp.Y = point.Y;
                temp.X = point.X;

                temp.Y -= cubeSize * i;
                temp.X += cubeSize * i;
                if (objectsCache.TryGetValue(temp, out counter))
                {
                    offset += counter / 100.0 + 0.01;
                }
                temp.Y = point.Y;
                temp.X = point.X;

                temp.Y += cubeSize * i;
                temp.X -= cubeSize * i;
                if (objectsCache.TryGetValue(temp, out counter))
                {
                    offset += counter / 100.0 + 0.01;
                }
                temp.Y = point.Y;
                temp.X = point.X; 
            }
            return offset;
        }

        private void DrawNode(System.Windows.Point point, NodeEntity node, double offset)
        {
            GeometryModel3D firstObj = new GeometryModel3D();
            firstObj.Material = new DiffuseMaterial(Brushes.DeepSkyBlue);
            Positions = new Point3DCollection()
            {
                new Point3D(point.X, point.Y, 0+ offset),
                new Point3D(point.X + cubeSize, point.Y, 0+offset),
                new Point3D(point.X, point.Y + cubeSize, 0 + offset),
                new Point3D(point.X + cubeSize, point.Y + cubeSize, 0+offset),
                new Point3D(point.X, point.Y, cubeSize+offset),
                new Point3D(point.X + cubeSize, point.Y, cubeSize+offset),
                new Point3D(point.X , point.Y + cubeSize, cubeSize+offset),
                new Point3D(point.X + cubeSize, point.Y + cubeSize, cubeSize+offset),
            };
            //firstObj.Transform 

            Indicies = new Int32Collection()
            {
                2,3,1,  2,1,0,  7,1,3,  7,5,1,  6,5,7,  6,4,5,  6,2,4,  2,0,4,  2,7,3,  2,6,7,  0,1,5,  0,5,4
            };

            firstObj.Geometry = new MeshGeometry3D() { Positions = Positions, TriangleIndices = Indicies };

            models.Add(firstObj);
            allObjects.Add(node);

            geomap.Children.Add(firstObj);
        }

        private void DrawSwitches()
        {
            foreach (var @switch in xmlParser.NetworkModel.Switches)
            {
                double latitude;
                double longitude;

                ToLatLon(@switch.X, @switch.Y, 34, out latitude, out longitude);
                if (latitude < 45.2325 || latitude > 45.277031 || longitude < 19.793909 || longitude > 19.894459)
                    continue;

                System.Windows.Point point = ApproximateFunction(latitude, longitude);
                if(@switch.Id == "41390")
                {
                    int x = 4;
                }

                double offset = GetOffset(point);
                DrawSwitch(point, @switch, offset);
                SaveObjectToCache(point);
            }
        }

        private void DrawSwitch(System.Windows.Point point, SwitchEntity @switch, double offset)
        {
            GeometryModel3D firstObj = new GeometryModel3D();
            firstObj.Material = new DiffuseMaterial(Brushes.Green);

            Positions = new Point3DCollection()
            {
                new Point3D(point.X, point.Y, 0+ offset),
                new Point3D(point.X + cubeSize, point.Y, 0+offset),
                new Point3D(point.X, point.Y + cubeSize, 0 + offset),
                new Point3D(point.X + cubeSize, point.Y + cubeSize, 0+offset),
                new Point3D(point.X, point.Y, cubeSize+offset),
                new Point3D(point.X + cubeSize, point.Y, cubeSize+offset),
                new Point3D(point.X , point.Y + cubeSize, cubeSize+offset),
                new Point3D(point.X + cubeSize, point.Y + cubeSize, cubeSize+offset),
            };

            Indicies = new Int32Collection()
            {
                2,3,1,  2,1,0,  7,1,3,  7,5,1,  6,5,7,  6,4,5,  6,2,4,  2,0,4,  2,7,3,  2,6,7,  0,1,5,  0,5,4
            };

            firstObj.Geometry = new MeshGeometry3D() { Positions = Positions, TriangleIndices = Indicies };

            models.Add(firstObj);
            allObjects.Add(@switch);

            geomap.Children.Add(firstObj);
        }

        private void DrawSubstations()
        {
            foreach (var substation in xmlParser.NetworkModel.Substations)
            {
                double latitude;
                double longitude;

                ToLatLon(substation.X, substation.Y, 34, out latitude, out longitude);
                if (latitude < 45.2325 || latitude > 45.277031 || longitude < 19.793909 || longitude > 19.894459)
                    continue;

                System.Windows.Point point = ApproximateFunction(latitude, longitude);

                double offset = GetOffset(point);
                DrawSub(point, substation, offset);
                SaveObjectToCache(point);
            }
        }

        private void SaveObjectToCache(System.Windows.Point point)
        {
            System.Windows.Point temp = new System.Windows.Point(Math.Round(point.X, 2), Math.Round(point.Y, 2));

            if (!objectsCache.ContainsKey(temp))
            {
                objectsCache[temp] = 0;
            }

            objectsCache[temp]++;
        }

        private void DrawSub(System.Windows.Point point, SubstationEntity substation, double offset)
        {
            GeometryModel3D firstObj = new GeometryModel3D();
            firstObj.Material = new DiffuseMaterial(Brushes.Black);

            Positions = new Point3DCollection()
            {
                new Point3D(point.X, point.Y, 0+ offset),
                new Point3D(point.X + cubeSize, point.Y, 0+offset),
                new Point3D(point.X, point.Y + cubeSize, 0 + offset),
                new Point3D(point.X + cubeSize, point.Y + cubeSize, 0+offset),
                new Point3D(point.X, point.Y, cubeSize+offset),
                new Point3D(point.X + cubeSize, point.Y, cubeSize+offset),
                new Point3D(point.X , point.Y + cubeSize, cubeSize+offset),
                new Point3D(point.X + cubeSize, point.Y + cubeSize, cubeSize+offset),
            };

            Indicies = new Int32Collection()
            {
                2,3,1,  2,1,0,  7,1,3,  7,5,1,  6,5,7,  6,4,5,  6,2,4,  2,0,4,  2,7,3,  2,6,7,  0,1,5,  0,5,4
            };

            firstObj.Geometry = new MeshGeometry3D() { Positions = Positions, TriangleIndices = Indicies };

            models.Add(firstObj);
            allObjects.Add(substation);

            geomap.Children.Add(firstObj);
        }

        private System.Windows.Point ApproximateFunction(double X, double Y)
        {
            System.Windows.Point point = new System.Windows.Point();

            point.Y = (X - minX) / (maxX - minX) * (mapSize - cubeSize);
            point.X = (Y - minY) / (maxY - minY) * (mapSize - cubeSize);

            return point;
        }

        public static void ToLatLon(double utmX, double utmY, int zoneUTM, out double latitude, out double longitude)
        {
            bool isNorthHemisphere = true;

            var diflat = -0.00066286966871111111111111111111111111;
            var diflon = -0.0003868060578;

            var zone = zoneUTM;
            var c_sa = 6378137.000000;
            var c_sb = 6356752.314245;
            var e2 = Math.Pow((Math.Pow(c_sa, 2) - Math.Pow(c_sb, 2)), 0.5) / c_sb;
            var e2cuadrada = Math.Pow(e2, 2);
            var c = Math.Pow(c_sa, 2) / c_sb;
            var x = utmX - 500000;
            var y = isNorthHemisphere ? utmY : utmY - 10000000;

            var s = ((zone * 6.0) - 183.0);
            var lat = y / (c_sa * 0.9996);
            var v = (c / Math.Pow(1 + (e2cuadrada * Math.Pow(Math.Cos(lat), 2)), 0.5)) * 0.9996;
            var a = x / v;
            var a1 = Math.Sin(2 * lat);
            var a2 = a1 * Math.Pow((Math.Cos(lat)), 2);
            var j2 = lat + (a1 / 2.0);
            var j4 = ((3 * j2) + a2) / 4.0;
            var j6 = ((5 * j4) + Math.Pow(a2 * (Math.Cos(lat)), 2)) / 3.0;
            var alfa = (3.0 / 4.0) * e2cuadrada;
            var beta = (5.0 / 3.0) * Math.Pow(alfa, 2);
            var gama = (35.0 / 27.0) * Math.Pow(alfa, 3);
            var bm = 0.9996 * c * (lat - alfa * j2 + beta * j4 - gama * j6);
            var b = (y - bm) / v;
            var epsi = ((e2cuadrada * Math.Pow(a, 2)) / 2.0) * Math.Pow((Math.Cos(lat)), 2);
            var eps = a * (1 - (epsi / 3.0));
            var nab = (b * (1 - epsi)) + lat;
            var senoheps = (Math.Exp(eps) - Math.Exp(-eps)) / 2.0;
            var delt = Math.Atan(senoheps / (Math.Cos(nab)));
            var tao = Math.Atan(Math.Cos(delt) * Math.Tan(nab));

            longitude = ((delt * (180.0 / Math.PI)) + s) + diflon;
            latitude = ((lat + (1 + e2cuadrada * Math.Pow(Math.Cos(lat), 2) - (3.0 / 2.0) * e2cuadrada * Math.Sin(lat) * Math.Cos(lat) * (tao - lat)) * (tao - lat)) * (180.0 / Math.PI)) + diflat;
        }

        private void Viewport3D_LeftClick(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Point mouseposition = e.GetPosition(viewPort3d);

            Point3D testpoint3D = new Point3D(mouseposition.X, mouseposition.Y, 0);
            Vector3D testdirection = new Vector3D(mouseposition.X, mouseposition.Y, 10);

            PointHitTestParameters pointparams = new PointHitTestParameters(mouseposition);
            RayHitTestParameters rayparams = new RayHitTestParameters(testpoint3D, testdirection);

            VisualTreeHelper.HitTest(viewPort3d, null, HTResult, pointparams);
        }

        private HitTestResultBehavior HTResult(System.Windows.Media.HitTestResult rawresult)
        {
            RayHitTestResult rayResult = rawresult as RayHitTestResult;

            if (rayResult != null)
            {
                bool isMapHited = true;
                for (int i = 0; i < models.Count; i++)
                {
                    if ((GeometryModel3D)models[i] == rayResult.ModelHit)
                    {
                        object ob = allObjects[i];
                        string id = "", name = "", type = "";
                        isMapHited = false;

                        if ((ob as SubstationEntity) != null)
                        {
                            id = (ob as SubstationEntity).Id;
                            name = (ob as SubstationEntity).Name;
                            type = "Substation";
                        }
                        else if ((ob as SwitchEntity) != null)
                        {
                            id = (ob as SwitchEntity).Id;
                            name = (ob as SwitchEntity).Name;
                            type = "Switch";
                        }
                        else if ((ob as NodeEntity) != null)
                        {
                            id = (ob as NodeEntity).Id;
                            name = (ob as NodeEntity).Name;
                            type = "Node";
                        }

                        toolTip.Content = String.Format("Id: {0}\nName: {1}\nType: {2}", id, name, type);
                        toolTip.Foreground = Brushes.Yellow;
                        toolTip.Background = Brushes.Black;
                        toolTip.IsOpen = true;

                        break;
                    }
                }

                if (isMapHited)
                    toolTip.IsOpen = false;
            }

            return HitTestResultBehavior.Stop;
        }

        private void viewport1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            start = e.GetPosition(viewPort3d);
            diffOffset.X = translacija.OffsetX;
            diffOffset.Y = translacija.OffsetY;
            viewPort3d.CaptureMouse();
        }

        private void viewport1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            viewPort3d.ReleaseMouseCapture();
        }

        private void viewport1_MouseMove(object sender, MouseEventArgs e)
        {
            if (viewPort3d.IsMouseCaptured)
            {
                System.Windows.Point end = e.GetPosition(viewPort3d);
                double offsetX = end.X - start.X;
                double offsetY = end.Y - start.Y;
                double w = this.Width;
                double h = this.Height;
                double translateX = (offsetX * 100) / w;
                double translateY = -(offsetY * 100) / h;
                translacija.OffsetX = diffOffset.X + (translateX / (100 * skaliranje.ScaleX));
                translacija.OffsetY = diffOffset.Y + (translateY / (100 * skaliranje.ScaleX));
            }
            if (e.MiddleButton == MouseButtonState.Pressed)
            {
                System.Windows.Point currentLocation = Mouse.GetPosition(this);

                // We want to rotate around the center of the knob, not the top corner
                System.Windows.Point knobCenter = new System.Windows.Point(this.ActualHeight / 2, this.ActualWidth / 2);

                // Calculate an angle
                double radians = Math.Atan((currentLocation.Y - knobCenter.Y) /
                                           (currentLocation.X - knobCenter.X));
                axisAngle.Angle = radians * 180 / Math.PI;

                // Apply a 180 degree shift when X is negative so that we can rotate
                // all of the way around
                if (currentLocation.X - knobCenter.X < 0)
                {
                    axisAngle.Angle += 180;
                }
            }
        }

        private void viewport1_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            System.Windows.Point p = e.MouseDevice.GetPosition(this);
            double scaleX = 1;
            double scaleY = 1;

            if (e.Delta > 0 && zoomCurent < zoomMax)
            {
                scaleX = skaliranje.ScaleX + 0.1;
                scaleY = skaliranje.ScaleY + 0.1;
                zoomCurent++;
                skaliranje.ScaleX = scaleX;
                skaliranje.ScaleY = scaleY;
            }
            else if (e.Delta <= 0 && zoomCurent > -zoomMax)
            {
                scaleX = skaliranje.ScaleX - 0.1;
                scaleY = skaliranje.ScaleY - 0.1;
                zoomCurent--;
                skaliranje.ScaleX = scaleX;
                skaliranje.ScaleY = scaleY;
            }


        }

        private void MouseDown(object sender, MouseButtonEventArgs e)
        {
            startRotation = e.GetPosition(this);
        }
    }
}
