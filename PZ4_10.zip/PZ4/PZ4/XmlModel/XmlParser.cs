﻿using PZ3.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace PZ3.XmlModel
{
    public class XmlParser
    {
        private NetworkModel networkModel;

        public XmlParser() { LoadXmlFile(); }

        public NetworkModel NetworkModel
        {
            get { return networkModel; }
            set { networkModel = value; }
        }
        //minX = 400131.73351085943, minY = 5004702.121711, maxX = 417718.172328868, maxY = 5020125.5628049225
        private void LoadXmlFile()
        {
            //double minX = 100000000, minY = 100000000, maxX = 0, maxY = 0;
            if (File.Exists("Geographic.xml"))
            {
                var serializer = new XmlSerializer(typeof(NetworkModel));
                using (var stream = File.OpenRead("Geographic.xml"))
                {
                    NetworkModel = (NetworkModel)(serializer.Deserialize(stream));

                    //foreach(var el in NetworkModel.Nodes)
                    //{
                    //    if (el.X < minX)
                    //        minX = el.X;
                    //    if (el.Y < minY)
                    //        minY = el.Y;

                    //    if (el.X > maxX)
                    //        maxX = el.X;
                    //    if (el.Y > maxY)
                    //        maxY = el.Y;
                    //}

                    //foreach(var el in NetworkModel.Substations)
                    //{
                    //    if (el.X < minX)
                    //        minX = el.X;
                    //    if (el.Y < minY)
                    //        minY = el.Y;

                    //    if (el.X > maxX)
                    //        maxX = el.X;
                    //    if (el.Y > maxY)
                    //        maxY = el.Y;
                    //}

                    //foreach (var el in NetworkModel.Switches)
                    //{
                    //    if (el.X < minX)
                    //        minX = el.X;
                    //    if (el.Y < minY)
                    //        minY = el.Y;

                    //    if (el.X > maxX)
                    //        maxX = el.X;
                    //    if (el.Y > maxY)
                    //        maxY = el.Y;
                    //}

                    return;
                }
            }
            NetworkModel = new NetworkModel();
        }
    }
}
